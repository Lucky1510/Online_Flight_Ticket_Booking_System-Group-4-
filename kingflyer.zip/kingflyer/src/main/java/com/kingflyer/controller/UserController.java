package com.kingflyer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kingflyer.constant.Constant;
import com.kingflyer.dto.UserDto;
import com.kingflyer.exception.DataNotCorrectException;
import com.kingflyer.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	UserService userService;
	
	@PostMapping("/userLogin/{userName}/{password}")
	public String userLogin(@RequestParam String userName, @RequestParam String password) {
		
		boolean isUserAdded = userService.loginUser(userName, password);
		
		if(isUserAdded) {
			return Constant.LOGIN_SUCCESSFULL;
		}
		
		throw new DataNotCorrectException();
	}
	
	@PostMapping("/registerUser")
	public String addUser(@RequestBody UserDto userDto) {
		
		boolean isUserAdded = userService.addUser(userDto);
		
		if(isUserAdded) {
			return Constant.ADDITION_SUCCESSFULL;
		}
		
		throw new DataNotCorrectException();
	}

	@PostMapping("/updateUser")
	public String updateUser(@RequestBody UserDto userDto){
		
		boolean isUserUpdate= userService.modifyUser(userDto);
		
		if(isUserUpdate) {
			return Constant.UPDATE_SUCCESSFULL;
		}
		throw new DataNotCorrectException();
	}
	
	@PostMapping("/deleteUser/{userName}/{password}")
	public String deleteUser(@RequestParam String userName, @RequestParam String password){
		
		boolean isUserUpdate= userService.deleteUser(userName, password);
		
		if(isUserUpdate) {
			return Constant.DELETION_SUCCESSFULL;
		}
		throw new DataNotCorrectException();
	}
	
}
