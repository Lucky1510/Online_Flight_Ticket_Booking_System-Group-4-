package com.kingflyer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kingflyer.constant.Constant;
import com.kingflyer.dto.AdminDto;
import com.kingflyer.exception.DataNotCorrectException;
import com.kingflyer.service.AdminService;

@RestController
public class AdminController {
	
	@Autowired
	AdminService adminService;
	
	@PostMapping("/adminLogin/{userName}/{password}")
	public String adminLogin(@PathVariable String userName, @PathVariable String password) {
		
		boolean isUserAdded = adminService.loginAdmin(userName, password);
		
		if(isUserAdded) {
			return Constant.LOGIN_SUCCESSFULL;
		}
		
		throw new DataNotCorrectException();
	}
	
	@PostMapping("/registerAdmin")
	public String addAdmin(@RequestBody AdminDto adminDto) {
		
		boolean isUserAdded = adminService.addAdmin(adminDto);
		
		if(isUserAdded) {
			return Constant.ADDITION_SUCCESSFULL;
		}
		
		throw new DataNotCorrectException();
	}
	
	@PostMapping("/updateAdmin")
	public String updateAdmin(@RequestBody AdminDto adminDto){
		
		boolean isUserUpdate= adminService.updateAdmin(adminDto);
		
		if(isUserUpdate) {
			return Constant.UPDATE_SUCCESSFULL;
		}
		throw new DataNotCorrectException();
	}
	
	@PostMapping("/deleteAdmin/{userName}/{password}")
	public String deleteAdmin(@RequestParam String userName, @RequestParam String password){
		
		boolean isUserUpdate= adminService.deleteAdmin(userName, password);
		
		if(isUserUpdate) {
			return Constant.DELETION_SUCCESSFULL;
		}
		throw new DataNotCorrectException();
	}
}
