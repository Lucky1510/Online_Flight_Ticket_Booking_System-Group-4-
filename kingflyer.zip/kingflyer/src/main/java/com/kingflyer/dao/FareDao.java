package com.kingflyer.dao;

import org.springframework.data.repository.CrudRepository;

import com.kingflyer.model.Fare;

public interface FareDao extends CrudRepository<Fare,Integer>{

}
